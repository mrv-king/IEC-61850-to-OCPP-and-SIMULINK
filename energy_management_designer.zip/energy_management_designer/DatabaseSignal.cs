﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace energy_management_designer
{
    public class DatabaseSignal
    {
        private string object_name;
        private string related_signal;

        public string ObjectName
        {
            get { return object_name; }
            set { object_name = value; }
        }

        public string RelatedSignal
        {
            get { return related_signal; }
            set { related_signal = value; }
        }

        public DatabaseSignal(string object_name, string related_signal)
        {
            this.object_name = object_name;
            this.related_signal = related_signal;
        }
    }
}
