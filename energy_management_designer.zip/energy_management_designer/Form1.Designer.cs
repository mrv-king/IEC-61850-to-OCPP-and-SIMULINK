﻿
namespace energy_management_designer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.main_tc = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.save_matlab_script_btn = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.button6 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.CSnumber_cb = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cs_functions_DataView = new System.Windows.Forms.DataGridView();
            this.define_signals_dataGV = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CS3_ip = new System.Windows.Forms.TextBox();
            this.CS2_ip = new System.Windows.Forms.TextBox();
            this.CS1_ip = new System.Windows.Forms.TextBox();
            this.CS3_tab2 = new System.Windows.Forms.PictureBox();
            this.CS2_tab2 = new System.Windows.Forms.PictureBox();
            this.CS1_tab2 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.add_label = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.hmi_dataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView_cs = new System.Windows.Forms.DataGridView();
            this.dataGridView_cms = new System.Windows.Forms.DataGridView();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView_cs2 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dataGridViev_deploy = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.CMSrichText = new System.Windows.Forms.RichTextBox();
            this.CPrichText = new System.Windows.Forms.RichTextBox();
            this.main_tc.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cs_functions_DataView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.define_signals_dataGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CS3_tab2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CS2_tab2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CS1_tab2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hmi_dataGridView)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_cs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_cms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_cs2)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViev_deploy)).BeginInit();
            this.SuspendLayout();
            // 
            // main_tc
            // 
            this.main_tc.Controls.Add(this.tabPage7);
            this.main_tc.Controls.Add(this.tabPage1);
            this.main_tc.Controls.Add(this.tabPage2);
            this.main_tc.Controls.Add(this.tabPage3);
            this.main_tc.Controls.Add(this.tabPage4);
            this.main_tc.Controls.Add(this.tabPage6);
            this.main_tc.Controls.Add(this.tabPage5);
            this.main_tc.Location = new System.Drawing.Point(-1, -2);
            this.main_tc.Name = "main_tc";
            this.main_tc.SelectedIndex = 0;
            this.main_tc.Size = new System.Drawing.Size(1729, 622);
            this.main_tc.TabIndex = 1;
            this.main_tc.SelectedIndexChanged += new System.EventHandler(this.main_tc_SelectedIndexChanged);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tabControl1);
            this.tabPage7.Controls.Add(this.label12);
            this.tabPage7.Controls.Add(this.label11);
            this.tabPage7.Controls.Add(this.label10);
            this.tabPage7.Controls.Add(this.label9);
            this.tabPage7.Controls.Add(this.button7);
            this.tabPage7.Controls.Add(this.save_matlab_script_btn);
            this.tabPage7.Controls.Add(this.richTextBox1);
            this.tabPage7.Controls.Add(this.treeView1);
            this.tabPage7.Controls.Add(this.button6);
            this.tabPage7.Location = new System.Drawing.Point(4, 29);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1721, 589);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Upload SCD file";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Location = new System.Drawing.Point(966, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(525, 552);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.CMSrichText);
            this.tabPage8.Location = new System.Drawing.Point(4, 29);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(517, 519);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "CMS script";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.CPrichText);
            this.tabPage9.Location = new System.Drawing.Point(4, 29);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(517, 931);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "CP script";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1174, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(151, 20);
            this.label12.TabIndex = 9;
            this.label12.Text = "OCPP script preview";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(650, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(172, 20);
            this.label11.TabIndex = 8;
            this.label11.Text = "MATLAB script preview";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(416, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 20);
            this.label10.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(140, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(216, 20);
            this.label9.TabIndex = 6;
            this.label9.Text = "XML structure of the SCD file";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(1499, 170);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(207, 52);
            this.button7.TabIndex = 4;
            this.button7.Text = "Generate OCPP script";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // save_matlab_script_btn
            // 
            this.save_matlab_script_btn.Location = new System.Drawing.Point(1499, 88);
            this.save_matlab_script_btn.Name = "save_matlab_script_btn";
            this.save_matlab_script_btn.Size = new System.Drawing.Size(207, 52);
            this.save_matlab_script_btn.TabIndex = 3;
            this.save_matlab_script_btn.Text = "Generate MATLAB script";
            this.save_matlab_script_btn.UseVisualStyleBackColor = true;
            this.save_matlab_script_btn.Click += new System.EventHandler(this.save_matlab_script_btn_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(502, 30);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(460, 552);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(19, 30);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(477, 552);
            this.treeView1.TabIndex = 1;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1499, 11);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(208, 49);
            this.button6.TabIndex = 0;
            this.button6.Text = "Open a new SCD file";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.CSnumber_cb);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1721, 589);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Choose the topology";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(824, 528);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "The number of CSs";
            // 
            // CSnumber_cb
            // 
            this.CSnumber_cb.FormattingEnabled = true;
            this.CSnumber_cb.Location = new System.Drawing.Point(980, 520);
            this.CSnumber_cb.Name = "CSnumber_cb";
            this.CSnumber_cb.Size = new System.Drawing.Size(55, 28);
            this.CSnumber_cb.TabIndex = 17;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(134, 129);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(459, 320);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(602, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(434, 489);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cs_functions_DataView);
            this.tabPage2.Controls.Add(this.define_signals_dataGV);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.CS3_ip);
            this.tabPage2.Controls.Add(this.CS2_ip);
            this.tabPage2.Controls.Add(this.CS1_ip);
            this.tabPage2.Controls.Add(this.CS3_tab2);
            this.tabPage2.Controls.Add(this.CS2_tab2);
            this.tabPage2.Controls.Add(this.CS1_tab2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1721, 589);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Define signals";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cs_functions_DataView
            // 
            this.cs_functions_DataView.AllowDrop = true;
            this.cs_functions_DataView.AllowUserToAddRows = false;
            this.cs_functions_DataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cs_functions_DataView.Location = new System.Drawing.Point(7, 340);
            this.cs_functions_DataView.Name = "cs_functions_DataView";
            this.cs_functions_DataView.ReadOnly = true;
            this.cs_functions_DataView.RowHeadersVisible = false;
            this.cs_functions_DataView.RowHeadersWidth = 62;
            this.cs_functions_DataView.RowTemplate.Height = 28;
            this.cs_functions_DataView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.cs_functions_DataView.Size = new System.Drawing.Size(931, 239);
            this.cs_functions_DataView.TabIndex = 10;
            this.cs_functions_DataView.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.cs_functions_DataView_CellMouseDown);
            this.cs_functions_DataView.DragEnter += new System.Windows.Forms.DragEventHandler(this.cs_functions_DataView_DragEnter);
            this.cs_functions_DataView.DragOver += new System.Windows.Forms.DragEventHandler(this.cs_functions_DataView_DragOver);
            this.cs_functions_DataView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cs_functions_DataView_MouseMove);
            // 
            // define_signals_dataGV
            // 
            this.define_signals_dataGV.AllowDrop = true;
            this.define_signals_dataGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.define_signals_dataGV.Location = new System.Drawing.Point(944, 8);
            this.define_signals_dataGV.Name = "define_signals_dataGV";
            this.define_signals_dataGV.RowHeadersVisible = false;
            this.define_signals_dataGV.RowHeadersWidth = 62;
            this.define_signals_dataGV.RowTemplate.Height = 28;
            this.define_signals_dataGV.Size = new System.Drawing.Size(296, 572);
            this.define_signals_dataGV.TabIndex = 9;
            this.define_signals_dataGV.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.define_signals_dataGV_CellBeginEdit);
            this.define_signals_dataGV.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.define_signals_dataGV_CellEndEdit);
            this.define_signals_dataGV.DragDrop += new System.Windows.Forms.DragEventHandler(this.define_signals_dataGV_DragDrop);
            this.define_signals_dataGV.DragEnter += new System.Windows.Forms.DragEventHandler(this.define_signals_dataGV_DragEnter);
            this.define_signals_dataGV.DragOver += new System.Windows.Forms.DragEventHandler(this.define_signals_dataGV_DragOver);
            this.define_signals_dataGV.MouseMove += new System.Windows.Forms.MouseEventHandler(this.define_signals_dataGV_MouseMove);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(639, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "CS3 IP address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(324, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "CS2 IP address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "CS1 IP address";
            // 
            // CS3_ip
            // 
            this.CS3_ip.Location = new System.Drawing.Point(640, 54);
            this.CS3_ip.Name = "CS3_ip";
            this.CS3_ip.Size = new System.Drawing.Size(298, 26);
            this.CS3_ip.TabIndex = 5;
            // 
            // CS2_ip
            // 
            this.CS2_ip.Location = new System.Drawing.Point(326, 54);
            this.CS2_ip.Name = "CS2_ip";
            this.CS2_ip.Size = new System.Drawing.Size(298, 26);
            this.CS2_ip.TabIndex = 4;
            // 
            // CS1_ip
            // 
            this.CS1_ip.Location = new System.Drawing.Point(14, 55);
            this.CS1_ip.Name = "CS1_ip";
            this.CS1_ip.Size = new System.Drawing.Size(298, 26);
            this.CS1_ip.TabIndex = 3;
            this.CS1_ip.Enter += new System.EventHandler(this.CS1_ip_Enter);
            this.CS1_ip.Validated += new System.EventHandler(this.CS1_ip_Validated);
            // 
            // CS3_tab2
            // 
            this.CS3_tab2.Image = ((System.Drawing.Image)(resources.GetObject("CS3_tab2.Image")));
            this.CS3_tab2.Location = new System.Drawing.Point(640, 97);
            this.CS3_tab2.Name = "CS3_tab2";
            this.CS3_tab2.Size = new System.Drawing.Size(298, 237);
            this.CS3_tab2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CS3_tab2.TabIndex = 2;
            this.CS3_tab2.TabStop = false;
            // 
            // CS2_tab2
            // 
            this.CS2_tab2.Image = ((System.Drawing.Image)(resources.GetObject("CS2_tab2.Image")));
            this.CS2_tab2.Location = new System.Drawing.Point(327, 95);
            this.CS2_tab2.Name = "CS2_tab2";
            this.CS2_tab2.Size = new System.Drawing.Size(298, 239);
            this.CS2_tab2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CS2_tab2.TabIndex = 1;
            this.CS2_tab2.TabStop = false;
            // 
            // CS1_tab2
            // 
            this.CS1_tab2.Image = ((System.Drawing.Image)(resources.GetObject("CS1_tab2.Image")));
            this.CS1_tab2.Location = new System.Drawing.Point(14, 95);
            this.CS1_tab2.Name = "CS1_tab2";
            this.CS1_tab2.Size = new System.Drawing.Size(298, 239);
            this.CS1_tab2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CS1_tab2.TabIndex = 0;
            this.CS1_tab2.TabStop = false;
            this.CS1_tab2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.CS1_tab2_MouseDoubleClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Controls.Add(this.hmi_dataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1721, 589);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Create the HMI";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.add_label);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(8, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(226, 484);
            this.panel1.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 375);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "One value scope";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(84, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Graph";
            // 
            // add_label
            // 
            this.add_label.AutoSize = true;
            this.add_label.Location = new System.Drawing.Point(72, 325);
            this.add_label.Name = "add_label";
            this.add_label.Size = new System.Drawing.Size(70, 20);
            this.add_label.TabIndex = 5;
            this.add_label.Text = "Put label";
            this.add_label.Click += new System.EventHandler(this.add_label_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(22, 402);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(174, 26);
            this.textBox4.TabIndex = 5;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(12, 132);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(201, 162);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(51, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 72);
            this.button1.TabIndex = 3;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // hmi_dataGridView
            // 
            this.hmi_dataGridView.AllowUserToAddRows = false;
            this.hmi_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hmi_dataGridView.Location = new System.Drawing.Point(8, 502);
            this.hmi_dataGridView.Name = "hmi_dataGridView";
            this.hmi_dataGridView.RowHeadersVisible = false;
            this.hmi_dataGridView.RowHeadersWidth = 62;
            this.hmi_dataGridView.RowTemplate.Height = 28;
            this.hmi_dataGridView.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.hmi_dataGridView.Size = new System.Drawing.Size(1232, 78);
            this.hmi_dataGridView.TabIndex = 3;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.dataGridView_cs);
            this.tabPage4.Controls.Add(this.dataGridView_cms);
            this.tabPage4.Controls.Add(this.pictureBox7);
            this.tabPage4.Controls.Add(this.pictureBox8);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1721, 589);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Connect signals";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(476, 518);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = "label5";
            // 
            // dataGridView_cs
            // 
            this.dataGridView_cs.AllowDrop = true;
            this.dataGridView_cs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_cs.Location = new System.Drawing.Point(950, 5);
            this.dataGridView_cs.Name = "dataGridView_cs";
            this.dataGridView_cs.RowHeadersVisible = false;
            this.dataGridView_cs.RowHeadersWidth = 62;
            this.dataGridView_cs.RowTemplate.Height = 28;
            this.dataGridView_cs.Size = new System.Drawing.Size(296, 574);
            this.dataGridView_cs.TabIndex = 28;
            this.dataGridView_cs.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_cs_CellMouseDown);
            this.dataGridView_cs.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGridView_cs_DragDrop);
            this.dataGridView_cs.DragEnter += new System.Windows.Forms.DragEventHandler(this.dataGridView_cs_DragEnter);
            this.dataGridView_cs.DragOver += new System.Windows.Forms.DragEventHandler(this.dataGridView_cs_DragOver);
            this.dataGridView_cs.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dataGridView_cs_MouseMove);
            // 
            // dataGridView_cms
            // 
            this.dataGridView_cms.AllowDrop = true;
            this.dataGridView_cms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_cms.Location = new System.Drawing.Point(4, 6);
            this.dataGridView_cms.Name = "dataGridView_cms";
            this.dataGridView_cms.RowHeadersVisible = false;
            this.dataGridView_cms.RowHeadersWidth = 62;
            this.dataGridView_cms.RowTemplate.Height = 28;
            this.dataGridView_cms.Size = new System.Drawing.Size(296, 574);
            this.dataGridView_cms.TabIndex = 27;
            this.dataGridView_cms.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_cms_CellMouseDown);
            this.dataGridView_cms.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGridView_cms_DragDrop);
            this.dataGridView_cms.DragEnter += new System.Windows.Forms.DragEventHandler(this.dataGridView_cms_DragEnter);
            this.dataGridView_cms.DragOver += new System.Windows.Forms.DragEventHandler(this.dataGridView_cms_DragOver);
            this.dataGridView_cms.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dataGridView_cms_MouseMove);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(290, 145);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(340, 251);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 18;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.InitialImage")));
            this.pictureBox8.Location = new System.Drawing.Point(638, 72);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(310, 385);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 17;
            this.pictureBox8.TabStop = false;
            // 
            // tabPage6
            // 
            this.tabPage6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage6.BackgroundImage")));
            this.tabPage6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage6.Controls.Add(this.dataGridView_cs2);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1721, 589);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Connect signals 2";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dataGridView_cs2
            // 
            this.dataGridView_cs2.AllowDrop = true;
            this.dataGridView_cs2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_cs2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_cs2.Name = "dataGridView_cs2";
            this.dataGridView_cs2.RowHeadersVisible = false;
            this.dataGridView_cs2.RowHeadersWidth = 62;
            this.dataGridView_cs2.RowTemplate.Height = 28;
            this.dataGridView_cs2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView_cs2.Size = new System.Drawing.Size(303, 583);
            this.dataGridView_cs2.TabIndex = 1;
            this.dataGridView_cs2.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGridView_cs2_DragDrop);
            this.dataGridView_cs2.DragEnter += new System.Windows.Forms.DragEventHandler(this.dataGridView_cs2_DragEnter);
            this.dataGridView_cs2.DragOver += new System.Windows.Forms.DragEventHandler(this.dataGridView_cs2_DragOver);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dataGridViev_deploy);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Controls.Add(this.button4);
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.label8);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1721, 589);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "      Deploy      ";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dataGridViev_deploy
            // 
            this.dataGridViev_deploy.AllowDrop = true;
            this.dataGridViev_deploy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViev_deploy.Location = new System.Drawing.Point(8, 8);
            this.dataGridViev_deploy.Name = "dataGridViev_deploy";
            this.dataGridViev_deploy.RowHeadersVisible = false;
            this.dataGridViev_deploy.RowHeadersWidth = 62;
            this.dataGridViev_deploy.RowTemplate.Height = 28;
            this.dataGridViev_deploy.Size = new System.Drawing.Size(1227, 362);
            this.dataGridViev_deploy.TabIndex = 29;
            this.dataGridViev_deploy.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViev_deploy_CellContentClick);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(477, 408);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(126, 48);
            this.button5.TabIndex = 4;
            this.button5.Text = "STOP";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(70, 412);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(128, 85);
            this.button4.TabIndex = 3;
            this.button4.Text = "START";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(741, 411);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(196, 85);
            this.button3.TabIndex = 2;
            this.button3.Text = "ShutD";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(651, 426);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "label8";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(272, 408);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 89);
            this.button2.TabIndex = 0;
            this.button2.Text = "set_variable";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // CMSrichText
            // 
            this.CMSrichText.Location = new System.Drawing.Point(0, 6);
            this.CMSrichText.Name = "CMSrichText";
            this.CMSrichText.Size = new System.Drawing.Size(511, 510);
            this.CMSrichText.TabIndex = 0;
            this.CMSrichText.Text = "";
            // 
            // CPrichText
            // 
            this.CPrichText.Location = new System.Drawing.Point(1, 0);
            this.CPrichText.Name = "CPrichText";
            this.CPrichText.Size = new System.Drawing.Size(517, 516);
            this.CPrichText.TabIndex = 0;
            this.CPrichText.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1740, 618);
            this.Controls.Add(this.main_tc);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "IEC61850 -> Charging stations";
            this.main_tc.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cs_functions_DataView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.define_signals_dataGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CS3_tab2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CS2_tab2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CS1_tab2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hmi_dataGridView)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_cs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_cms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_cs2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViev_deploy)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CSnumber_cb;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox CS3_ip;
        private System.Windows.Forms.TextBox CS2_ip;
        private System.Windows.Forms.TextBox CS1_ip;
        private System.Windows.Forms.PictureBox CS3_tab2;
        private System.Windows.Forms.PictureBox CS2_tab2;
        private System.Windows.Forms.PictureBox CS1_tab2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView define_signals_dataGV;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.DataGridView dataGridView_cs;
        private System.Windows.Forms.DataGridView dataGridView_cms;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView hmi_dataGridView;
        private System.Windows.Forms.TabControl main_tc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label add_label;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridViev_deploy;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView dataGridView_cs2;
        private System.Windows.Forms.DataGridView cs_functions_DataView;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button save_matlab_script_btn;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.RichTextBox CMSrichText;
        private System.Windows.Forms.RichTextBox CPrichText;
    }
}

