﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using Renci.SshNet;
using WebSocketSharp.Server;
using System.Xml;
using System.IO.Compression;
using System.Text;

namespace energy_management_designer
{
    public partial class Form1 : Form
    {
        public OleDbConnection database;
        string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Environment.CurrentDirectory + "\\database\\config.mdb;";
        string prev_string_name = "";
        string prev_string_direction = "";
        string CS1_ip_prev_value = "";
        bool HMI_first_entrance = true;
        int button_counter = 0;
        string last_click_obj_name = "";
        List<Button> buttons = new List<Button>();
        List<int> button_occupied_indexes = new List<int>();
        List<Label> labels = new List<Label>();
        List<int> label_occupied_indexes = new List<int>();
        List<System.Windows.Forms.DataVisualization.Charting.Chart> charts = new List<System.Windows.Forms.DataVisualization.Charting.Chart>();
        List<int> chart_occupied_indexes = new List<int>();
        string drag_drop_value = "";
        WebSocketServer ws = null;

        List<Object_61850> _61850_objects;
        List<Object_matlab> MATLAB_objects;
        Object_61850 simple_object = new Object_61850(string.Empty, string.Empty, string.Empty, string.Empty);

        XmlDocument xmldoc;

        struct Coordinate
        {
            public int x;
            public int y;
        }

        Coordinate mouseDownPoint;

        public Form1()
        {
            InitializeComponent();
            CSnumber_cb.Items.Add(1);
            CSnumber_cb.Items.Add(2);
            CSnumber_cb.Items.Add(3);
            CSnumber_cb.SelectedIndex = 0;
            dataGridView_cms.AllowUserToAddRows = false;
            dataGridView_cs.AllowUserToAddRows = false;
            dataGridView_cs2.AllowUserToAddRows = false;

            _61850_objects = new List<Object_61850>();
            MATLAB_objects = new List<Object_matlab>();
            simple_object = new Object_61850(string.Empty, string.Empty, string.Empty, string.Empty);

            bool[] BBB_P9_HEADER_DIO = { false, false, false, false, false, false, false, false, false, false,
                                         true, true, true, true, true, true, true, true, true, true,
                                         true, true, true, true, true, true, true, true, true, true,
                                         true, false, true, false, true, true, true, true, true, true,
                                         true, true, false, false, false, false };

            bool[] BBB_P8_HEADER_DIO = { false, false, true, true, true, true, true, true, true, true,
                                         true, true, true, true, true, true, true, true, true, true,
                                         true, true, true, true, true, true, true, true, true, true,
                                         true, true, true, true, true, true, true, true, true, true,
                                         true, true, true, true, true, true };

            Button button = null;
            int delta_y = 0;

            for (int i = 0; i< BBB_P9_HEADER_DIO.Length; i++)
            {
                if (BBB_P9_HEADER_DIO[i])   {
                    button = new Button();
                    button.Width = 60;
                    button.Height = 11;
                    button.Name = "P9_" + (i+1).ToString();
   
                    button.Top = 87 + delta_y * 11;

                    button.AllowDrop = true;
                    button.FlatAppearance.BorderSize = 0;
                    button.FlatAppearance.MouseDownBackColor = Color.Transparent;
                    button.FlatAppearance.MouseOverBackColor = Color.Transparent;
                    button.FlatStyle = FlatStyle.Flat;
                    button.ForeColor = BackColor;

                    button.MouseDown += hided_buttons_mouse_down_handler;
                    button.MouseMove += hided_buttons_mouse_move_handler;
                    if (i % 2 != 0)
                        button.Left = 450;
                    else
                        button.Left = 350;

                    tabPage6.Controls.Add(button);
                }
                if (i % 2 != 0)
                    delta_y++;
            }

            delta_y = 0;

            for (int i = 0; i < BBB_P8_HEADER_DIO.Length; i++)
            {
                if (BBB_P8_HEADER_DIO[i])
                {
                    button = new Button();
                    button.Width = 60;
                    button.Height = 11;
                    button.Name = "P8_" + (i+1).ToString();
                    button.Top = 87 + delta_y * 11;

                    button.AllowDrop = true;
                    button.FlatAppearance.BorderSize = 0;
                    button.FlatAppearance.MouseDownBackColor = Color.Transparent;
                    button.FlatAppearance.MouseOverBackColor = Color.Transparent;
                    button.FlatStyle = FlatStyle.Flat;
                    button.ForeColor = BackColor;

                    button.MouseDown += hided_buttons_mouse_down_handler;
                    button.MouseMove += hided_buttons_mouse_move_handler;
                    if (i % 2 != 0)
                        button.Left = 770;
                    else
                        button.Left = 670;

                    tabPage6.Controls.Add(button);
                }
                if (i % 2 != 0)
                    delta_y++;
            }

            try
            {
                database = new OleDbConnection(connectionString);
                database.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void hided_buttons_mouse_down_handler(object sender, EventArgs e)
        {
            Button button = sender as Button;
            drag_drop_value = button.Name;
        }

        private void hided_buttons_mouse_move_handler(object sender, MouseEventArgs e)
        {
            if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
            {
                DragDropEffects dropEffect = dataGridView_cs2.DoDragDrop(drag_drop_value, DragDropEffects.Copy);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            CS1_ip.Enabled = true;
            CS1_tab2.Enabled = true;
            CS2_ip.Enabled = true;
            CS2_tab2.Enabled = true;
            CS3_ip.Enabled = true;
            CS3_tab2.Enabled = true;

            main_tc.SelectedTab = tabPage2;

            if (CSnumber_cb.SelectedIndex == 0)
            {
                CS2_ip.Enabled = false;
                CS2_tab2.Enabled = false;
                CS3_ip.Enabled = false;
                CS3_tab2.Enabled = false;
            }
            if (CSnumber_cb.SelectedIndex == 1)
            {
                CS3_ip.Enabled = false;
                CS3_tab2.Enabled = false;
            }

        }

        public void loadDataGrid(DataGridView dataGridView, string query)
        {
            try
            {
                dataGridView.Columns.Clear();
                OleDbCommand SQLQuery = new OleDbCommand();
                SQLQuery.CommandText = query;
                SQLQuery.Connection = database;
                DataTable data = new DataTable();
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(SQLQuery);
                dataAdapter.Fill(data);
                dataGridView.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void WriteValuetoDatabase(string query)
        {
            try
            {
                OleDbCommand SQLQuery = new OleDbCommand();
                SQLQuery.CommandText = query;
                SQLQuery.Connection = database;
                DataTable data = new DataTable();
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(SQLQuery);
                dataAdapter.Fill(data);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public string ReadOneValue(string connectionString, string query, string param_name)
        {
            string result = "";
            using (var conection = new OleDbConnection(connectionString))
            {
                conection.Open();
                var command = new OleDbCommand(query, conection);
                var reader = command.ExecuteReader();
                while (reader.Read())
                    result = reader[param_name].ToString();
            }
            return result;
        }

        public HashSet<DatabaseSignal> convertDatabase2Array(string connectionString, string query)
        {
            string result = "";
            HashSet<DatabaseSignal> localHash = new HashSet<DatabaseSignal>();

            using (var conection = new OleDbConnection(connectionString))
            {
                conection.Open();
                var command = new OleDbCommand(query, conection);
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    localHash.Add(new DatabaseSignal(reader[0].ToString(), reader[1].ToString()));
                }
            }
            return localHash;
        }

        private List<HMI_OBJECT> get_array_of_objects(string connectionString, string query)
        {
            List<HMI_OBJECT> list = new List<HMI_OBJECT>();
            using (var conection = new OleDbConnection(connectionString))
            {
                conection.Open();
                var command = new OleDbCommand(query, conection);
                var reader = command.ExecuteReader();
                while (reader.Read())
                    list.Add(new HMI_OBJECT(reader["type"].ToString(), reader["name"].ToString(), reader["obj_text"].ToString(), reader["related_signal"].ToString(), reader["posX"].ToString(), reader["posY"].ToString(), reader["width"].ToString(), reader["height"].ToString()));
            }
            return list;
        }

        private void CS1_tab2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            loadDataGrid(define_signals_dataGV, "select direction, name from CS1_signals_cfg order by direction ASC");
        }

        private void define_signals_dataGV_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                prev_string_name = define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                prev_string_direction = define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex - 1].Value.ToString();
            }
            else
            {
                prev_string_direction = define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                prev_string_name = define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex + 1].Value.ToString();
            }
        }

        private void define_signals_dataGV_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string answer_option = "";
            string cell_value_name = "";
            string cell_value_direction = "";
            OleDbConnection con = null;
            OleDbCommand oconn = null;
            var result = DialogResult.Cancel;

            if (e.ColumnIndex == 1)
            {
                cell_value_name = define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                cell_value_direction = define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex - 1].Value.ToString();

                if (prev_string_direction.Length != 0 && cell_value_name.Length != 0)
                    WriteValuetoDatabase("update CS1_signals_cfg set direction = '" + cell_value_direction + "', name = '" + cell_value_name + "' where name = '" + prev_string_name + "'");
                else
                {
                    if (cell_value_name.Length != 0)
                    {
                        const string message =
                            "Press 'Yes' to specify the direction of signal as Output, otherwise press 'No'. Press 'Cancel' to abort.";
                        const string caption = "Specify direction as the output?";
                        result = MessageBox.Show(message, caption,
                                                     MessageBoxButtons.YesNoCancel,
                                                     MessageBoxIcon.Question);
                        if (result == DialogResult.Yes)
                            answer_option = "O";
                        if (result == DialogResult.No)
                            answer_option = "I";

                        if (answer_option.Length != 0)
                            WriteValuetoDatabase("insert into CS1_signals_cfg values ('" + answer_option + "','" + cell_value_name + "')");
                    }
                }
                if (result != DialogResult.Cancel)
                {
                    con.Open();
                    OleDbDataAdapter sda = new OleDbDataAdapter(oconn);
                    DataTable data = new DataTable();
                    sda.Fill(data);
                    define_signals_dataGV.DataSource = data;
                }
                else
                {
                    define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "";
                    define_signals_dataGV.Rows[e.RowIndex].Cells[e.ColumnIndex - 1].Value = "";
                }
            }
        }

        private void CS1_ip_Validated(object sender, EventArgs e)
        {
            WriteValuetoDatabase("update CS1_ip_cfg set ip_address = '" + CS1_ip.Text + "' where ip_address = '" + CS1_ip_prev_value + "'");
        }

        private void CS1_ip_Enter(object sender, EventArgs e)
        {
            CS1_ip.Text = ReadOneValue(connectionString, "SELECT * FROM CS1_ip_cfg", "ip_address");
            CS1_ip_prev_value = CS1_ip.Text;
        }

        public Button button_id_from_click()
        {
            Button result = null;
            int mouse_left = Cursor.Position.X - this.Left - 10;
            int mouse_top = Cursor.Position.Y - this.Top - 50;
            foreach (Button button in buttons)
            {
                if (button.Left < mouse_left && (button.Left + button.Size.Width) > mouse_left && button.Top < mouse_top && (button.Top + button.Size.Height) > mouse_top)
                    result = button;
            }
            return result;
        }

        public Label label_id_from_click()
        {
            Label result = null;
            int mouse_left = Cursor.Position.X - this.Left - 10;
            int mouse_top = Cursor.Position.Y - this.Top - 50;
            foreach (Label label in labels)
            {
                if (label.Left < mouse_left && (label.Left + label.Size.Width) > mouse_left && label.Top < mouse_top && (label.Top + label.Size.Height) > mouse_top)
                    result = label;
            }
            return result;
        }

        private Button generate_button(List<int> button_occupied_indexes)
        {
            int top = 200;
            int left = 200;

            int current_index = 0;
            for (int i = 0; i < 100; i++)
            {
                if (button_occupied_indexes.IndexOf(i) == -1)
                {
                    button_occupied_indexes.Add(i);
                    current_index = i;
                    i = 101;
                }
            }

            Button button = new Button();
            button.Left = left;
            button.Top = top;
            button.Name = "button_" + current_index.ToString();
            tabPage3.Controls.Add(button);
            button.Text = button.Name;
            ControlExtension.Draggable(button, true);
            button.AllowDrop = true;
            button.DragLeave += button_drag_leave;
            button.MouseUp += (sender_loc, e_loc) =>
            {
                if (e_loc.Button == MouseButtons.Right)
                {
                    Button rclick_id = button_id_from_click();
                    ContextMenu cm = new ContextMenu();
                    cm.MenuItems.Add(new MenuItem("Delete", new EventHandler((_sender, _e) => button_delete(sender_loc, e_loc, button))));
                    cm.MenuItems.Add(new MenuItem("Rename", button_rename));
                    cm.MenuItems.Add(new MenuItem("Bind signal", bind_signal_to_butoon));
                    cm.MenuItems.Add(new MenuItem("Unbind signal", unbind_signal_from_object));
                    button.ContextMenu = cm;
                    last_click_obj_name = button.Name;
                }
                if (e_loc.Button == MouseButtons.Left)
                {
                    last_click_obj_name = button.Name;
                    my_object_click_func();
                    Button rclick_id = button_id_from_click();
                    if (rclick_id != null)
                    {
                        rclick_id.DoDragDrop(" ", DragDropEffects.Copy | DragDropEffects.Move);
                    }

                }
            };
            buttons.Add(button);

            return button;
        }

        private void generate_button(string name, string text, int posX, int posY, int width, int height)
        {
            Button button = new Button();
            button.Left = posX;
            button.Top = posY;
            button.Name = name;
            button.Text = text;
            tabPage3.Controls.Add(button);
            button.Height = height;
            button.Width = width;
            button.AllowDrop = true;
            ControlExtension.Draggable(button, true);
            button.DragLeave += button_drag_leave;
            button.MouseUp += (sender_loc, e_loc) =>
            {
                if (e_loc.Button == MouseButtons.Right)
                {
                    ContextMenu cm = new ContextMenu();
                    cm.MenuItems.Add(new MenuItem("Delete", new EventHandler((_sender, _e) => button_delete(sender_loc, e_loc, button))));
                    cm.MenuItems.Add(new MenuItem("Rename", button_rename));
                    cm.MenuItems.Add(new MenuItem("Bind signal", bind_signal_to_butoon));
                    cm.MenuItems.Add(new MenuItem("Unbind signal", unbind_signal_from_object));
                    button.ContextMenu = cm;
                    last_click_obj_name = button.Name;
                }
                if (e_loc.Button == MouseButtons.Left)
                {
                    last_click_obj_name = button.Name;
                    my_object_click_func();
                    Button rclick_id = button_id_from_click();
                    if (rclick_id != null)
                    {
                        rclick_id.DoDragDrop(" ", DragDropEffects.Copy | DragDropEffects.Move);
                    }

                }
            };
            buttons.Add(button);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button button = generate_button(button_occupied_indexes);
            WriteValuetoDatabase("insert into CS1_HMI_cfg values ('button','" + button.Name.ToString() + "','" + button.Name + "','-','" + button.Top.ToString() + "','" + button.Left.ToString() + "','" + button.Width.ToString() + "','" + button.Height.ToString() + "', 0)");
        }

        private void button_delete(object sender, EventArgs e, Button btn)
        {
            WriteValuetoDatabase("delete from CS1_HMI_cfg where name='" + btn.Name + "'");
            foreach (Button button in buttons)
            {
                if (button.Name == btn.Name)
                {
                    buttons.Remove(button);
                    break;
                }
            }
            tabPage3.Controls.Remove(btn);
        }

        private List<int> build_list_of_free_button_ids(List<Button> buttons)
        {
            List<int> accum = new List<int>();
            int current_id = 0;
            int underscore_index = "button_".IndexOf('_') + 1;
            foreach (Button button in buttons)
            {
                if (Int32.TryParse(button.Name.Substring(underscore_index, button.Name.Length - underscore_index), out current_id))
                    accum.Add(current_id);
                else
                    MessageBox.Show($"Unable to parse '{button.Name}'");
            }
            if (accum.Any())
                accum.Sort();

            return accum;
        }

        private List<int> build_list_of_free_label_ids(List<Label> labels)
        {
            List<int> accum = new List<int>();
            int current_id = 0;
            int underscore_index = "label_".IndexOf('_') + 1;
            foreach (Label label in labels)
            {
                if (Int32.TryParse(label.Name.Substring(underscore_index, label.Name.Length - underscore_index), out current_id))
                    accum.Add(current_id);
                else
                    MessageBox.Show($"Unable to parse '{label.Name}'");
            }
            if (accum.Any())
                accum.Sort();

            return accum;
        }

        public void button_rename(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(last_click_obj_name, "text", 1);
            form2.Size = new Size(290, 80);
            form2.ShowDialog();
            foreach (Button btn in buttons)
            {
                if (btn.Name == form2.button_name)
                    btn.Text = form2.button_text;
            }
        }

        public void bind_signal_to_butoon(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(last_click_obj_name, "related_signal", 0);
            form2.Size = new Size(290, 290);
            form2.ShowDialog();
        }

        public void unbind_signal_from_object(object sender, EventArgs e)
        {
            WriteValuetoDatabase("update CS1_HMI_cfg set related_signal = '-' where name = '" + last_click_obj_name + "'");
        }

        private void main_tc_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (main_tc.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    loadDataGrid(cs_functions_DataView, "select * from CS_functions");
                    cs_functions_DataView.Columns[0].Width = 200;
                    cs_functions_DataView.Columns[1].Width = cs_functions_DataView.Width - 220;
                    break;
                case 2:
                    if (HMI_first_entrance == true)
                    {
                        List<HMI_OBJECT> list = get_array_of_objects(connectionString, "SELECT * FROM CS1_HMI_cfg");
                        foreach (var obj in list)
                        {
                            switch (obj.Type)
                            {
                                case "button":
                                    generate_button(obj.Name, obj.Text, Int32.Parse(obj.PosX), Int32.Parse(obj.PosY), Int32.Parse(obj.Width), Int32.Parse(obj.Height));
                                    break;
                                case "label":
                                    generate_label(obj.Name, obj.Text, Int32.Parse(obj.PosX), Int32.Parse(obj.PosY), Int32.Parse(obj.Width), Int32.Parse(obj.Height));
                                    break;
                                case "chart":
                                    generate_chart(obj.Name, obj.Text, Int32.Parse(obj.PosX), Int32.Parse(obj.PosY), Int32.Parse(obj.Width), Int32.Parse(obj.Height));
                                    break;
                            }
                        }
                        button_occupied_indexes = build_list_of_free_button_ids(buttons);
                        label_occupied_indexes = build_list_of_free_label_ids(labels);
                        HMI_first_entrance = false;
                    }
                    break;
                case 3:
                    parse_signalmap_over_centralstation();
                    break;
                case 4:
                    loadDataGrid(dataGridView_cs2, "select object_name, related_to from signals_relation where (object_name NOT LIKE 'button_%' and object_name NOT LIKE 'chart_%') ");
                    break;
                case 5:
                    deploy_tab_content();
                    break;
            }
        }

        public string beaglebone_IO_name_from_click()
        {
            int mouse_left = Cursor.Position.X - this.Left - 220;
            int mouse_top = Cursor.Position.Y - this.Top - 50;
            //MessageBox.Show("mouse left: "+mouse_left.ToString()+", mouse_top: "+mouse_top.ToString());
            if (mouse_left > 135 && mouse_left < 167)
            {
                if (mouse_top > 147 && mouse_top <= 159)
                    drag_drop_value = "GPIO_30";
            }
            return drag_drop_value;
        }

        private void pictureBox_BB_MouseDown(object sender, MouseEventArgs e)
        {
            //MessageBox.Show(beaglebone_IO_name_from_click());
            beaglebone_IO_name_from_click();
        }

        private void button_drag_leave(object sender, EventArgs e)
        {
            Button btn = button_id_from_click();
            if (btn != null)
                WriteValuetoDatabase("update CS1_HMI_cfg set posX = '" + btn.Left + "', posY = '" + btn.Top + "' where name = '" + btn.Name + "'");
        }

        private void label_drag_leave(object sender, EventArgs e)
        {
            Label lbl = label_id_from_click();
            if (lbl != null)
                WriteValuetoDatabase("update CS1_HMI_cfg set posX = '" + lbl.Left + "', posY = '" + lbl.Top + "' where name = '" + lbl.Name + "'");
        }

        private void add_label_Click(object sender, EventArgs e)
        {
            Label label = generate_label(label_occupied_indexes);
            WriteValuetoDatabase("insert into CS1_HMI_cfg values ('label','" + label.Name + "','" + label.Name + "','-','" + label.Top.ToString() + "','" + label.Left.ToString() + "','" + label.Width.ToString() + "','" + label.Height.ToString() + "')");
        }

        private Label generate_label(List<int> labels_occupied_indexes)
        {
            int top = 200;
            int left = 200;

            int current_index = 0;
            for (int i = 0; i < 100; i++)
            {
                if (labels_occupied_indexes.IndexOf(i) == -1)
                {
                    labels_occupied_indexes.Add(i);
                    current_index = i;
                    i = 101;
                }
            }
            Label label = new Label();
            label.Left = left;
            label.Top = top;
            label.Name = "label_" + current_index.ToString();
            tabPage3.Controls.Add(label);
            label.Text = label.Name;
            ControlExtension.Draggable(label, true);
            label.AllowDrop = true;
            label.DragLeave += label_drag_leave;
            label.MouseUp += (sender_loc, e_loc) =>
            {
                if (e_loc.Button == MouseButtons.Right)
                {
                    Label rclick_id = label_id_from_click();
                    ContextMenu cm = new ContextMenu();
                    cm.MenuItems.Add(new MenuItem("Delete", new EventHandler((_sender, _e) => label_delete(sender_loc, e_loc, label))));
                    cm.MenuItems.Add(new MenuItem("Rename", label_rename));
                    label.ContextMenu = cm;
                    last_click_obj_name = label.Name;
                }
                if (e_loc.Button == MouseButtons.Left)
                {
                    Label rclick_id = label_id_from_click();
                    if (rclick_id != null)
                    {
                        rclick_id.DoDragDrop(" ", DragDropEffects.Copy | DragDropEffects.Move);
                    }
                }
            };
            labels.Add(label);
            return label;
        }

        private void generate_label(string name, string text, int posX, int posY, int width, int height)
        {
            Label label = new Label();
            label.Left = posX;
            label.Top = posY;
            label.Name = name;
            label.Text = text;
            tabPage3.Controls.Add(label);
            label.Height = height;
            label.Width = width;
            label.AllowDrop = true;
            ControlExtension.Draggable(label, true);
            label.DragLeave += label_drag_leave;
            label.MouseUp += (sender_loc, e_loc) =>
            {
                if (e_loc.Button == MouseButtons.Right)
                {
                    ContextMenu cm = new ContextMenu();
                    cm.MenuItems.Add(new MenuItem("Delete", new EventHandler((_sender, _e) => label_delete(sender_loc, e_loc, label))));
                    cm.MenuItems.Add(new MenuItem("Rename", label_rename));
                    label.ContextMenu = cm;
                    last_click_obj_name = label.Name;
                }
                if (e_loc.Button == MouseButtons.Left)
                {
                    Label rclick_id = label_id_from_click();
                    if (rclick_id != null)
                    {
                        rclick_id.DoDragDrop(" ", DragDropEffects.Copy | DragDropEffects.Move);
                    }
                }
            };
            labels.Add(label);
        }

        private void label_delete(object sender, EventArgs e, Label lbl)
        {
            WriteValuetoDatabase("delete from CS1_HMI_cfg where name='" + lbl.Name + "'");
            foreach (Label label in labels)
            {
                if (label.Name == lbl.Name)
                {
                    labels.Remove(label);
                    break;
                }
            }
            tabPage3.Controls.Remove(lbl);
        }

        public void label_rename(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(last_click_obj_name, "text", 1);
            form2.Size = new Size(300, 80);
            form2.ShowDialog();
            foreach (Label label in labels)
            {
                if (label.Name == form2.button_name)
                    label.Text = form2.button_text;
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.DataVisualization.Charting.Chart chart = generate_chart(chart_occupied_indexes);
            WriteValuetoDatabase("insert into CS1_HMI_cfg values ('chart','" + chart.Name.ToString() + "','" + chart.Name + "','-','" + chart.Top.ToString() + "','" + chart.Left.ToString() + "','" + chart.Width.ToString() + "','" + chart.Height.ToString() + "', 1)");
        }

        public System.Windows.Forms.DataVisualization.Charting.Chart chart_id_from_click()
        {
            System.Windows.Forms.DataVisualization.Charting.Chart result = null;
            int mouse_left = Cursor.Position.X - this.Left - 10;
            int mouse_top = Cursor.Position.Y - this.Top - 50;
            foreach (System.Windows.Forms.DataVisualization.Charting.Chart chart in charts)
            {
                if (chart.Left < mouse_left && (chart.Left + chart.Size.Width) > mouse_left && chart.Top < mouse_top && (chart.Top + chart.Size.Height) > mouse_top)
                    result = chart;
            }
            return result;
        }

        private System.Windows.Forms.DataVisualization.Charting.Chart generate_chart(List<int> charts_occupied_indexes)
        {
            int top = 200;
            int left = 200;

            int current_index = 0;
            for (int i = 0; i < 100; i++)
            {
                if (charts_occupied_indexes.IndexOf(i) == -1)
                {
                    charts_occupied_indexes.Add(i);
                    current_index = i;
                    i = 101;
                }
            }
            System.Windows.Forms.DataVisualization.Charting.Chart chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chart1.BorderlineColor = Color.Black;
            chart1.Name = "chart_" + current_index.ToString();
            chart1.Top = 100;
            chart1.Left = 200;
            chart1.ChartAreas.Add("default_area");
            chart1.Size = new Size(400, 200);
            var chart = chart1.ChartAreas[0];
            chart.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chart.AxisY.LabelStyle.IsEndLabelVisible = false;
            chart.AxisX.Minimum = 0;
            chart.AxisX.Interval = 5;
            chart.AxisX.Maximum = 60;
            chart.AxisY.Minimum = 0;
            chart.AxisY.Interval = 10;
            chart.AxisY.Maximum = 50;
            chart1.Series.Add("default");
            chart1.Series["default"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["default"].Color = Color.Blue;
            chart1.Series["default"].BorderWidth = 3;
            chart1.Series["default"].IsVisibleInLegend = false;
            chart1.Series["default"].Points.AddXY(0, 0);
            tabPage3.Controls.Add(chart1);
            chart1.MouseEnter += do_something;
            chart1.MouseLeave += do_something_else;
            chart1.MouseMove += do_something_third;
            ControlExtension.Draggable(chart1, true);
            chart1.AllowDrop = true;
            chart1.DragLeave += chart_drag_leave;
            chart1.MouseUp += (sender_loc, e_loc) =>
            {
                if (e_loc.Button == MouseButtons.Right)
                {
                    System.Windows.Forms.DataVisualization.Charting.Chart rclick_id = chart_id_from_click();
                    ContextMenu cm = new ContextMenu();
                    cm.MenuItems.Add(new MenuItem("Delete", new EventHandler((_sender, _e) => chart_delete(sender_loc, e_loc, chart1))));
                    cm.MenuItems.Add(new MenuItem("Bind signal", bind_signal_to_chart));
                    cm.MenuItems.Add(new MenuItem("Integrety period of signal", chart_integrity_period));
                    cm.MenuItems.Add(new MenuItem("Unbind signal", unbind_signal_from_object));
                    chart1.ContextMenu = cm;
                    last_click_obj_name = chart1.Name;
                }
                if (e_loc.Button == MouseButtons.Left)
                {
                    my_object_click_func();
                    System.Windows.Forms.DataVisualization.Charting.Chart rclick_id = chart_id_from_click();
                    if (rclick_id != null)
                    {
                        rclick_id.DoDragDrop(" ", DragDropEffects.Copy | DragDropEffects.Move);
                    }
                }
            };
            charts.Add(chart1);
            return chart1;
        }

        private void generate_chart(string name, string text, int posX, int posY, int width, int height)
        {
            int current_index = 0;
            for (int i = 0; i < 100; i++)
            {
                if (chart_occupied_indexes.IndexOf(i) == -1)
                {
                    chart_occupied_indexes.Add(i);
                    current_index = i;
                    i = 101;
                }
            }
            System.Windows.Forms.DataVisualization.Charting.Chart chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chart1.BorderlineColor = Color.Black;
            chart1.Name = name;
            chart1.Text = text;
            chart1.Left = posX;
            chart1.Top = posY;
            chart1.Height = height;
            chart1.Width = width;
            chart1.ChartAreas.Add("default_area");
            chart1.Size = new Size(400, 200);
            var chart = chart1.ChartAreas[0];
            chart.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chart.AxisY.LabelStyle.IsEndLabelVisible = false;
            chart.AxisX.Minimum = 0;
            chart.AxisX.Interval = 5;
            chart.AxisX.Maximum = 60;
            chart.AxisY.Minimum = 0;
            chart.AxisY.Interval = 10;
            chart.AxisY.Maximum = 50;
            chart1.Series.Add("default");
            chart1.Series["default"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["default"].Color = Color.Blue;
            chart1.Series["default"].BorderWidth = 3;
            chart1.Series["default"].IsVisibleInLegend = false;
            chart1.Series["default"].Points.AddXY(0, 0);
            tabPage3.Controls.Add(chart1);
            chart1.MouseEnter += do_something;
            chart1.MouseLeave += do_something_else;
            chart1.MouseMove += do_something_third;
            ControlExtension.Draggable(chart1, true);
            chart1.AllowDrop = true;
            chart1.DragLeave += chart_drag_leave;
            chart1.MouseUp += (sender_loc, e_loc) =>
            {
                if (e_loc.Button == MouseButtons.Right)
                {
                    System.Windows.Forms.DataVisualization.Charting.Chart rclick_id = chart_id_from_click();
                    ContextMenu cm = new ContextMenu();
                    cm.MenuItems.Add(new MenuItem("Delete", new EventHandler((_sender, _e) => chart_delete(sender_loc, e_loc, chart1))));
                    cm.MenuItems.Add(new MenuItem("Bind signal", bind_signal_to_chart));
                    cm.MenuItems.Add(new MenuItem("Integrety period of signal", chart_integrity_period));
                    cm.MenuItems.Add(new MenuItem("Unbind signal", unbind_signal_from_object));
                    chart1.ContextMenu = cm;
                    last_click_obj_name = chart1.Name;
                }
                if (e_loc.Button == MouseButtons.Left)
                {
                    last_click_obj_name = chart1.Name;
                    my_object_click_func();
                    System.Windows.Forms.DataVisualization.Charting.Chart rclick_id = chart_id_from_click();
                    if (rclick_id != null)
                    {
                        rclick_id.DoDragDrop(" ", DragDropEffects.Copy | DragDropEffects.Move);
                    }
                }
            };
            charts.Add(chart1);
        }

        private void my_object_click_func()
        {
            //System.Windows.Forms.DataVisualization.Charting.Chart chart = chart_id_from_click();
            loadDataGrid(hmi_dataGridView, "select * from CS1_HMI_cfg where name = '" + last_click_obj_name + "'");
            int max_num_cell = 9;
            for (int i = 0; i < max_num_cell; i++)
                hmi_dataGridView.Columns[i].Width = hmi_dataGridView.Width / max_num_cell;
        }

        private void chart_drag_leave(object sender, EventArgs e)
        {
            System.Windows.Forms.DataVisualization.Charting.Chart crt = chart_id_from_click();
            if (crt != null)
                WriteValuetoDatabase("update CS1_HMI_cfg set posX = '" + crt.Left + "', posY = '" + crt.Top + "' where name = '" + crt.Name + "'");
        }

        private void chart_delete(object sender, EventArgs e, System.Windows.Forms.DataVisualization.Charting.Chart chrt)
        {
            WriteValuetoDatabase("delete from CS1_HMI_cfg where name='" + chrt.Name + "'");
            foreach (System.Windows.Forms.DataVisualization.Charting.Chart chart in charts)
            {
                if (chart.Name == chrt.Name)
                {
                    charts.Remove(chart);
                    break;
                }
            }
            tabPage3.Controls.Remove(chrt);
        }

        public void bind_signal_to_chart(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(last_click_obj_name, "related_signal", 0);
            form2.Size = new Size(290, 290);
            form2.ShowDialog();
        }

        public void chart_integrity_period(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(last_click_obj_name, "related_signal", 2);
            form2.Size = new Size(290, 80);
            form2.ShowDialog();
        }

        private void do_something(object sender, EventArgs e)
        {
            //Here should be pasted code to recize duynamically the chart

        }
        private void do_something_else(object sender, EventArgs e)
        {
            //Here should be pasted code to recize duynamically the chart
        }

        private void do_something_third(object sender, EventArgs e)
        {
            //Here should be pasted code to recize duynamically the chart
        }

        private void parse_signalmap_over_centralstation()
        {
            WriteValuetoDatabase("DELETE FROM signals_relation");
            WriteValuetoDatabase("INSERT INTO signals_relation (object_name, related_to, integrety_period) SELECT name, related_signal, integrety_period FROM CS1_HMI_cfg where (name LIKE 'button_%' or name LIKE 'chart_%')");
            WriteValuetoDatabase("INSERT INTO signals_relation (object_name, related_to, integrety_period) SELECT name, ' ', 0 FROM CS1_signals_cfg");
            //loadDataGrid(dataGridView_cms, "select signal, related_to from signals_relation where (name LIKE 'button_%' or name LIKE 'chart_%')");
            //loadDataGrid(dataGridView_cs, "select signal, related_to from signals_relation where object_name = 'CS_1'");
        }

        private void dataGridView_cs_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void dataGridView_cs_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void dataGridView_cms_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void dataGridView_cms_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void dataGridView_cs2_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void dataGridView_cs2_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void dataGridView_cs2_DragDrop(object sender, DragEventArgs e)
        {
            Point clientPoint = dataGridView_cs2.PointToClient(new Point(e.X, e.Y));
            var hittest = dataGridView_cs2.HitTest(clientPoint.X, clientPoint.Y);
            string object_name = dataGridView_cs2.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value.ToString();

            if (object_name.IndexOf("voltage_") != -1 || object_name.IndexOf("current_") != -1)
            {
                if (drag_drop_value == "P9_33" || drag_drop_value == "P9_35" || drag_drop_value == "P9_36" || drag_drop_value == "P9_37" || drag_drop_value == "P9_38" || drag_drop_value == "P9_39" || drag_drop_value == "P9_40")
                {
                    dataGridView_cs2.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex].Value = drag_drop_value;
                    WriteValuetoDatabase("update signals_relation set related_to = '" + drag_drop_value + "' where object_name = '" + dataGridView_cs2.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value.ToString() + "'");
                }
                else
                    MessageBox.Show("You can assign only P9_33, P9_35, P9_36, P9_37, P9_38, P9_39, P9_40");
            }
            else
            {
                dataGridView_cs2.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex].Value = drag_drop_value;
                WriteValuetoDatabase("update signals_relation set related_to = '" + drag_drop_value + "' where object_name = '" + dataGridView_cs2.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value.ToString() + "'");
            }
        }

        private void dataGridView_cms_DragDrop(object sender, DragEventArgs e)
        {
            Point clientPoint = dataGridView_cms.PointToClient(new Point(e.X, e.Y));
            var hittest = dataGridView_cms.HitTest(clientPoint.X, clientPoint.Y);

            if (dataGridView_cms.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex].Style.BackColor == Color.LightGreen)
            {
                dataGridView_cms.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex].Value = drag_drop_value;
                dataGridView_cs.Rows[mouseDownPoint.x].Cells[mouseDownPoint.y].Value = dataGridView_cms.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value;
                WriteValuetoDatabase("update signals_relation set related_to = '" + dataGridView_cms.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value.ToString() + "' where signal = '" + drag_drop_value + "'");
                WriteValuetoDatabase("update signals_relation set related_to = '" + drag_drop_value + "' where signal = '" + dataGridView_cms.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value.ToString() + "'");
            }
            else
            {
                MessageBox.Show("You cannot connect input to input or output to output");
            }
            unhighlight_grid(dataGridView_cms);
        }

        private void dataGridView_cs_DragDrop(object sender, DragEventArgs e)
        {
            Point clientPoint = dataGridView_cs.PointToClient(new Point(e.X, e.Y));
            var hittest = dataGridView_cs.HitTest(clientPoint.X, clientPoint.Y);

            if (dataGridView_cs.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex].Style.BackColor == Color.LightGreen)
            {
                dataGridView_cs.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex].Value = drag_drop_value;
                dataGridView_cms.Rows[mouseDownPoint.x].Cells[mouseDownPoint.y].Value = dataGridView_cs.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value;
                WriteValuetoDatabase("update signals_relation set related_to = '" + dataGridView_cs.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value.ToString() + "' where signal = '" + drag_drop_value + "'");
                WriteValuetoDatabase("update signals_relation set related_to = '" + drag_drop_value + "' where signal = '" + dataGridView_cs.Rows[hittest.RowIndex].Cells[hittest.ColumnIndex - 1].Value.ToString() + "'");
            }
            else
            {
                MessageBox.Show("You cannot connect input to input or output to output");
            }
            unhighlight_grid(dataGridView_cs);
        }

        private void dataGridView_cs_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            drag_drop_value = dataGridView_cs.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            mouseDownPoint.x = e.RowIndex;
            mouseDownPoint.y = e.ColumnIndex + 1;

            string result = ReadOneValue(connectionString, "SELECT direction, name FROM CS1_signals_cfg where name = '" + drag_drop_value + "'", "direction");
            label5.Text = result;
            if (result == "I")
            {
                label5.Text = "Input";
                highlight_grid_cells(dataGridView_cms, "O");    //we need to seach the opposit direction in order to connect input to output
            }
            if (result == "O")
            {
                label5.Text = "output";
                highlight_grid_cells(dataGridView_cms, "I");    //we need to seach the opposit direction in order to connect input to output
            }
        }

        private void dataGridView_cms_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            drag_drop_value = dataGridView_cms.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            mouseDownPoint.x = e.RowIndex;
            mouseDownPoint.y = e.ColumnIndex + 1;

            string result = ReadOneValue(connectionString, "SELECT type, related_signal FROM CS1_HMI_cfg where related_signal = '" + drag_drop_value + "'", "type");
            label5.Text = result;
            if (result == "chart")
            {
                label5.Text = "Input";
                highlight_grid_cells(dataGridView_cs, "O");    //we need to seach the opposit direction in order to connect input to output
            }
            if (result == "button")
            {
                label5.Text = "output";
                highlight_grid_cells(dataGridView_cs, "I");    //we need to seach the opposit direction in order to connect input to output
            }
        }

        private void dataGridView_cms_MouseMove(object sender, MouseEventArgs e)
        {
            if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
            {
                DragDropEffects dropEffect = dataGridView_cms.DoDragDrop(drag_drop_value, DragDropEffects.Copy);
            }
        }

        private void dataGridView_cs_MouseMove(object sender, MouseEventArgs e)
        {
            if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
            {
                DragDropEffects dropEffect = dataGridView_cs.DoDragDrop(drag_drop_value, DragDropEffects.Copy);
            }
        }

        private void unhighlight_grid(DataGridView dataGridView)
        {
            int numRows = dataGridView.Rows.Count;
            for (int i = 0; i < numRows; i++)
            {
                dataGridView.Rows[i].Cells[1].Style.BackColor = Color.White;
            }
        }

        private void highlight_grid_cells(DataGridView dataGridView, string dir_variable)
        {
            string grid_param = "";
            string searching_result = "";
            string query = "";
            int counter = 0;

            if (dataGridView.Name == "dataGridView_cms")
            {
                query = "select * from CS1_HMI_cfg where type ='button' or type = 'chart'";
                grid_param = "type";
                if (dir_variable == "I")
                    searching_result = "chart";
                else
                    searching_result = "button";
            }

            else if (dataGridView.Name == "dataGridView_cs")
            {
                query = "select * from CS1_signals_cfg";
                grid_param = "direction";
                if (dir_variable == "I")
                    searching_result = "I";
                else
                    searching_result = "O";
            }

            using (var conection = new OleDbConnection(connectionString))
            {
                conection.Open();
                var command = new OleDbCommand(query, conection);
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (reader[grid_param].ToString() == searching_result)
                    {
                        dataGridView.Rows[counter].Cells[1].Style.BackColor = Color.LightGreen;
                    }
                    counter++;
                }
                label5.Text = counter.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ws.WebSocketServices["/CP_1"].Sessions.Broadcast("[2,\"32805d18-31cf-485b-89ce-3920fbb6631b\",\"SetVariables\",{\"setVariableData\":[{\"component\":{\"name\":\"current_sensor#1\"},\"variable\":{\"name\":\"current\"},\"attributeValue\":\"1.6\"}]}]");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            HashSet<DatabaseSignal> localHash = new HashSet<DatabaseSignal>();
            localHash = convertDatabase2Array(connectionString, "select object_name, related_to from signals_relation where (object_name LIKE 'button_%' or object_name LIKE 'chart_0')");
            foreach (var obj in localHash)
            {
                MessageBox.Show((obj.ObjectName, obj.RelatedSignal).ToString());
            }         
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ws = new WebSocketServer("ws://192.168.10.98:8080");
            ws.AddWebSocketService<OCPP>("/CP_1");
            ws.Start();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ws.Stop();
        }

        private void deploy_tab_content()
        {
            int number_of_sections = 4;
            int status_width = 60;
            int frame_width = (this.Width - 30 - status_width) / number_of_sections;

            dataGridViev_deploy.AllowUserToAddRows = false;
            dataGridViev_deploy.ScrollBars = ScrollBars.None;

            loadDataGrid(dataGridViev_deploy, "select ip_address from CS1_ip_cfg");
            dataGridViev_deploy.Columns[0].Width = frame_width;

            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            btn.HeaderText = "Detect";
            btn.Width = frame_width;
            btn.Text = "Send \"detect\" request";
            btn.UseColumnTextForButtonValue = true;
            dataGridViev_deploy.Columns.Add(btn);

            DataGridViewComboBoxColumn cmbx = new DataGridViewComboBoxColumn();
            cmbx.Width = frame_width;
            cmbx.HeaderText = "Device Type";
            cmbx.Items.Add("BeagleBone_Type");
            cmbx.Items.Add("custom");
            cmbx.Items.Add("auto");
            dataGridViev_deploy.Columns.Add(cmbx);

            dataGridViev_deploy.Columns.Add("status", "Status");
            dataGridViev_deploy.Columns[3].Width = status_width;

            btn = new DataGridViewButtonColumn();
            btn.HeaderText = "Deploy";
            btn.Text = "Deploy OCPP script";
            btn.Width = frame_width;
            btn.UseColumnTextForButtonValue = true;
            dataGridViev_deploy.Columns.Add(btn);
        }

        private void dataGridViev_deploy_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 1)
                {
                    var connectionInfo = new ConnectionInfo(dataGridViev_deploy.Rows[e.RowIndex].Cells[0].Value.ToString(), 22, "debian", new PasswordAuthenticationMethod("debian", "temppwd"));
                    using (var client = new SshClient(connectionInfo))
                    {
                        client.Connect();
                        if (client.IsConnected)
                        {
                            string result = client.CreateCommand("cd .. && cd /home && ls").Execute();
                            if (result.IndexOf("niko") != -1)
                            {
                                dataGridViev_deploy.Rows[0].Cells[2].Value = "BeagleBone_Type";
                                var cell = dataGridViev_deploy.Rows[0].Cells[3];
                                cell.Style.BackColor = Color.LightGreen;
                                cell.Value = "online";
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error");
                        }
                        client.Disconnect();
                    }
                }
                else if (e.ColumnIndex == 4)
                {
                    var connectionInfo = new ConnectionInfo(dataGridViev_deploy.Rows[e.RowIndex].Cells[0].Value.ToString(), 22, "debian", new PasswordAuthenticationMethod("debian", "temppwd"));
                    using (var client = new SshClient(connectionInfo))
                    {
                        client.Connect();
                        if (client.IsConnected)
                        {
                            string result = client.CreateCommand("cd .. && cd /home/niko && ls").Execute();
                            //if (result.IndexOf("test.py") != -1)
                            client.CreateCommand("cd .. && cd /home/niko && rm test.py").Execute();
                        }
                        client.Disconnect();
                    }

                    generate_ocpp_script();

                    using (var sftp = new SftpClient(connectionInfo))
                    {
                        sftp.Connect();
                        sftp.ChangeDirectory("/home/niko");
                        using (var uplfileStream = File.OpenRead("hello_world.txt"))
                        {
                            sftp.UploadFile(uplfileStream, @"test.py", true);
                        }
                        sftp.Disconnect();
                    }
                }
            }
        }

        private void generate_ocpp_script()
        {
            HashSet<DatabaseSignal> hmi_signals = new HashSet<DatabaseSignal>();
            HashSet<DatabaseSignal> bb_signals = new HashSet<DatabaseSignal>();
            hmi_signals = convertDatabase2Array(connectionString, "select object_name, related_to from signals_relation where (object_name LIKE 'button_%' or object_name LIKE 'chart_%')");
            bb_signals  = convertDatabase2Array(connectionString, "select object_name, related_to from signals_relation where (related_to LIKE 'P9_%' or related_to LIKE 'P8_%')");

            File.WriteAllText("hello_world.txt", String.Empty);
            using (StreamWriter sw = File.AppendText("hello_world.txt"))
            {
                sw.WriteLine(
@"import asyncio
import logging
import websockets
import sys
import threading
from datetime import datetime

from ocpp.v201 import call, call_result
from ocpp.v201 import ChargePoint as cp
from ocpp.routing import on

logging.basicConfig(level = logging.INFO)

import Adafruit_BBIO.ADC as ADC
import Adafruit_BBIO.GPIO as GPIO

class ChargePoint(cp):

    async def send_boot_notification(self):
        request = call.BootNotificationPayload(
            charging_station={
                'model': 'MODEL_123',
                'vendor_name': 'VENDOR_123'
            },
            reason='PowerUp'
        )
        response = await self.call(request)
        if response.status == 'Accepted':
            print('Connected to central system.')

    async def send_authorize_request(self):
        request = call.AuthorizePayload(
                id_token = {
                    'id_token' : '0xf4-Udz3-54!k-2204',
                    'type' : 'KeyCode'
                }
        )
        response = await self.call(request)
        if response.id_token_info.get('status','Never') == 'Accepted':
            print('Authorized to central system.')

    async def send_transaction_event_request(self):
        global send_transaction_event_counter
        request = call.TransactionEventPayload(
                event_type = 'Started',
                timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
                trigger_reason = 'EVDetected',
                seq_no = send_transaction_event_counter,
                transaction_info = {
                    'transactionId' : '32805d18-31cf-485b-89ce-3920fbb6631b'
                }
        )
        response = await self.call(request)
        send_transaction_event_counter = send_transaction_event_counter + 1
        if response.id_token_info.get('status', 'Never') == 'Accepted':
            print('SendTransactionEventRequest is confirmed by the CMS')

    @on('SetVariables')
    async def on_set_variables(self, set_variable_data, **kwargs):
        print('on_set_variable')
        set_variable_data[0].pop('attribute_value')
        is_var_changed = {'attribute_status': 'Accepted'}
        set_variable_data[0].update(is_var_changed)
        return call_result.SetVariablesPayload(
            set_variable_result = set_variable_data
        )

async def main():
    async with websockets.connect(
        'ws://192.168.10.98:8080/CP_1',
        subprotocols=['ocpp2.0']
    ) as ws:
        cp = ChargePoint('CP_1', ws)
        #await asyncio.gather(cp.start(), cp.send_boot_notification())
        await asyncio.gather(cp.start(), update_gpio(cp))
    sys.exit(0)


ADC.setup()

"
+ initialize_parameters(bb_signals)

+ initialize_updatefunc(bb_signals)

+ initialize_gpio(bb_signals)

+@"

if __name__ == '__main__':
    asyncio.run(main())");
            }
        }

        private string initialize_updatefunc(HashSet<DatabaseSignal> localHash)
        {
            string result =
@"async def update_gpio(cp):
    global counter
    while True:
        if counter == 0:
            await cp.send_boot_notification()
            counter = 1
        else:
";
            foreach (var obj in localHash)
            {
                if (obj.RelatedSignal.IndexOf("P8_") != -1 || obj.RelatedSignal.IndexOf("P9_") != -1)
                {
                    if (obj.ObjectName.IndexOf("switch_") != -1)
                        result += @"            if " + obj.ObjectName + " == 0:\n" +
                              @"                GPIO.output('" + obj.RelatedSignal + "', GPIO.LOW)\n" +
                              "            else:\n" +
                              @"                GPIO.output('" + obj.RelatedSignal + "', GPIO.HIGH)\n\n";
                    else if (obj.ObjectName.IndexOf("ev_detect_") != -1 || obj.ObjectName.IndexOf("authorization_") != -1 || obj.ObjectName.IndexOf("button_") != -1)
                    {
                        result += @"            if GPIO.input('" + obj.RelatedSignal + "'):\n";
                        result += "                " + obj.ObjectName + " = 1\n            else:\n                " + obj.ObjectName + " = 0\n\n";
                    }
                    else if (obj.ObjectName.IndexOf("current_") != -1 || obj.ObjectName.IndexOf("voltage_") != -1)
                    {
                        result += "            " + obj.ObjectName + " = ADC.read('" + obj.RelatedSignal + "')\n";
                    }
                }
            }

            result += "            await cp.send_transaction_event_request()\n";
            result += "            #await cp.send_authorize_request()\n";
            result += "            await asyncio.sleep(1)\n\n";
            return result;
        }

        private string initialize_parameters(HashSet<DatabaseSignal> localHash)
        {
            string result = @"counter = 0
send_transaction_event_counter = 0
"; // basic parameter
            foreach (var obj in localHash)
            {
                if (obj.RelatedSignal.IndexOf("P8_") != -1 || obj.RelatedSignal.IndexOf("P9_") != -1)
                {
                    result += obj.ObjectName + " = 0\n";
                }
            }
            result += "\n\n";
            return result;
        }

        private string initialize_gpio(HashSet<DatabaseSignal> localHash)
        {
            string result = "";
            foreach (var obj in localHash)
            {
                if (obj.RelatedSignal.IndexOf("P8_") != -1 || obj.RelatedSignal.IndexOf("P9_") != -1)
                {
                    if (obj.ObjectName.IndexOf("switch_") != -1)
                        result += "GPIO.setup('"+obj.RelatedSignal+ "', GPIO.OUT)\nGPIO.output('"+obj.RelatedSignal+"', GPIO.LOW)\n";
                    else if (obj.ObjectName.IndexOf("ev_detect_") != -1 || obj.ObjectName.IndexOf("authorization_") != -1 || obj.ObjectName.IndexOf("button_") != -1)
                        result += "GPIO.setup('"+obj.RelatedSignal+"', GPIO.IN)";
                }
            }
            result += "\n\n";
            return result;
        }

        private void cs_functions_DataView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            drag_drop_value = cs_functions_DataView.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void cs_functions_DataView_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void cs_functions_DataView_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void cs_functions_DataView_MouseMove(object sender, MouseEventArgs e)
        {
            if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
            {
                DragDropEffects dropEffect = cs_functions_DataView.DoDragDrop(drag_drop_value, DragDropEffects.Copy);
            }
        }

        private void define_signals_dataGV_MouseMove(object sender, MouseEventArgs e)
        {
            if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
            {
                DragDropEffects dropEffect = define_signals_dataGV.DoDragDrop(drag_drop_value, DragDropEffects.Copy);
            }
        }

        private void define_signals_dataGV_DragDrop(object sender, DragEventArgs e)
        {
            string direction = "";
            string name = "";

            if (drag_drop_value.IndexOf("button") != -1)
            {
                direction = "I";
                name = "button_";
            }
            else if (drag_drop_value.IndexOf("voltage_sensor") != -1)
            {
                direction = "I";
                name = "voltage_";
            }
            else if (drag_drop_value.IndexOf("current_sensor") != -1)
            {
                direction = "I";
                name = "current_";
            }
            else if (drag_drop_value.IndexOf("EV_detect") != -1)
            {
                direction = "I";
                name = "ev_detect_";
            }
            else if (drag_drop_value.IndexOf("authorization") != -1)
            {
                direction = "I";
                name = "authorization_";
            }
            else if (drag_drop_value.IndexOf("power_switch") != -1)
            {
                direction = "O";
                name = "switch_";
            }

            for (int i = 0; i<100; i++)
            {
                if (ReadOneValue(connectionString, "SELECT name FROM CS1_signals_cfg WHERE name = '" + name + i.ToString() + "'", "name").Length == 0)
                {
                    WriteValuetoDatabase("insert into CS1_signals_cfg values ('" + direction + "','" + name + i.ToString() + "')");
                    i = 100;
                    loadDataGrid(define_signals_dataGV, "SELECT * FROM CS1_signals_cfg");
                }         
            }   
        }

        private void define_signals_dataGV_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void define_signals_dataGV_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        // IEC61850 part ===================================================================================================================================================================

        private void button6_Click(object sender, EventArgs e)
        {
            string destination_filename = string.Empty;
            using (var fbd = new OpenFileDialog())
            {
                fbd.Filter = "SCD Files (*.scd)|*.scd";
                DialogResult result = fbd.ShowDialog();
                if (result == DialogResult.OK)
                {
                    _61850_objects.Clear();
                    MATLAB_objects.Clear();
                    destination_filename = fbd.FileName.ToString();
                    this.RenderXMLFile(destination_filename);
                    GenerateMatlabScript(_61850_objects);
                }
            }
        }

        private void RenderXMLFile(string filepath)
        {
            try
            {
                xmldoc = new XmlDocument();
                string xmlString_1 = File.ReadAllText("settingsdata.xml", Encoding.UTF8);
                xmldoc.LoadXml(xmlString_1);

                string xmlString = File.ReadAllText(filepath, Encoding.UTF8);
                XmlDocument dom = new XmlDocument();
                dom.LoadXml(xmlString);
                treeView1.Nodes.Clear();
                treeView1.Nodes.Add(new TreeNode(dom.DocumentElement.Name));
                TreeNode tNode = new TreeNode();
                tNode = treeView1.Nodes[0];
                this.AddNode(dom.DocumentElement, tNode);
            }
            catch (XmlException xmlEx)
            {
                MessageBox.Show(xmlEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AddNode(XmlNode inXmlNode, TreeNode inTreeNode)
        {
            XmlNode xNode;
            TreeNode tNode;
            XmlNodeList nodeList;
            short i;
            bool has_initiated = false;
            if (inXmlNode.HasChildNodes)
            {
                nodeList = inXmlNode.ChildNodes;
                for (i = 0; i <= nodeList.Count - 1; i++)
                {
                    xNode = inXmlNode.ChildNodes[i];
                    if (has_initiated)
                    {
                        _61850_objects.Add(simple_object);
                        simple_object = new Object_61850(string.Empty, string.Empty, string.Empty, string.Empty);
                        has_initiated = false;
                    }
                    if (xNode.Name == "ConductingEquipment")
                    {
                        has_initiated = true;
                        simple_object.Type = xNode.Attributes.GetNamedItem("type").Value;
                        simple_object.Name = xNode.Attributes.GetNamedItem("name").Value;
                        if (simple_object.Type.Equals("CON"))
                        {
                            MATLAB_objects.Add(ConfigurateMatlabObject(simple_object.Type, simple_object.Name));
                            //MATLAB_objects.Add(ConfigurateMatlabObject("INV", simple_object.Name + "_1"));
                        }
                        else
                            MATLAB_objects.Add(ConfigurateMatlabObject(simple_object.Type, simple_object.Name));
                        foreach (XmlNode childnode in xNode.ChildNodes)
                        {
                            if (childnode.Name == "Terminal")
                            {
                                simple_object.Connection = childnode.Attributes.GetNamedItem("connectivityNode").Value;
                                if (simple_object.FirstContName.Length == 0)
                                    simple_object.FirstContName = childnode.Attributes.GetNamedItem("connectivityNode").Value;
                                else
                                    simple_object.SecondContName = childnode.Attributes.GetNamedItem("connectivityNode").Value;
                            }
                        }
                    }
                    inTreeNode.Nodes.Add(new TreeNode(xNode.OuterXml.Trim()));
                    tNode = inTreeNode.Nodes[i];
                    this.AddNode(xNode, tNode);
                }
            }
            else
            {
                inTreeNode.Text = (inXmlNode.OuterXml).Trim();
            }
        }

        private Object_matlab ConfigurateMatlabObject(string object_type, string name)
        {
            Object_matlab local_matlab_obj = null;

            XmlNode NodeGen = xmldoc.SelectSingleNode("configuration");

            foreach (XmlNode childNode in NodeGen.ChildNodes)
            {
                if (childNode.Attributes.GetNamedItem("name").Value == object_type)
                {
                    if (childNode.Attributes.GetNamedItem("ports").Value == "one side" && childNode.Attributes.GetNamedItem("Lside_cont_num").Value == "1" && childNode.Attributes.GetNamedItem("Rside_cont_num").Value == "0")         //////////
                        local_matlab_obj = new Object_matlab(childNode.Attributes.GetNamedItem("path").Value, name, "/LConn1", "/LConn1", "/LConn1", "/LConn1", "/LConn1", "/LConn1", true, true, 1, 0);                                //
                    else if (childNode.Attributes.GetNamedItem("ports").Value == "one side" && childNode.Attributes.GetNamedItem("Lside_cont_num").Value == "0" && childNode.Attributes.GetNamedItem("Rside_cont_num").Value == "2")    //
                        local_matlab_obj = new Object_matlab(childNode.Attributes.GetNamedItem("path").Value, name, "/LConn2", "null", "null", "null", "/LConn1", "null", true, true, 0, 2);                                            //
                    else if (childNode.Attributes.GetNamedItem("ports").Value == "two side" && childNode.Attributes.GetNamedItem("Lside_cont_num").Value == "2" && childNode.Attributes.GetNamedItem("Rside_cont_num").Value == "2")    //
                        local_matlab_obj = new Object_matlab(childNode.Attributes.GetNamedItem("path").Value, name, "/LConn1", "/LConn2", "null", "/RConn1", "/RConn2", "null", true, true, 2, 2);                                      //
                    else if (childNode.Attributes.GetNamedItem("ports").Value == "two side" && childNode.Attributes.GetNamedItem("Lside_cont_num").Value == "2" && childNode.Attributes.GetNamedItem("Rside_cont_num").Value == "3")    //
                        local_matlab_obj = new Object_matlab(childNode.Attributes.GetNamedItem("path").Value, name, "/LConn2", "/LConn1", "null", "/RConn1", "/RConn2", "/RConn3", true, true, 2, 3);                                   //
                    else if (childNode.Attributes.GetNamedItem("ports").Value == "two side" && childNode.Attributes.GetNamedItem("Lside_cont_num").Value == "3" && childNode.Attributes.GetNamedItem("Rside_cont_num").Value == "2")    //
                        local_matlab_obj = new Object_matlab(childNode.Attributes.GetNamedItem("path").Value, name, "/LConn1", "/LConn2", "/LConn3", "/RConn1", "/RConn2", "null", true, true, 3, 2);                                   //
                    else if (childNode.Attributes.GetNamedItem("ports").Value == "two side" && childNode.Attributes.GetNamedItem("Lside_cont_num").Value == "3" && childNode.Attributes.GetNamedItem("Rside_cont_num").Value == "3")    //
                        local_matlab_obj = new Object_matlab(childNode.Attributes.GetNamedItem("path").Value, name, "/LConn1", "/LConn2", "/LConn3", "/RConn1", "/RConn2", "/RConn3", true, true, 3, 3);                                ///////////
                }
            }
            return local_matlab_obj;
        }
        private string InitializeMatlabScript()
        {
            string script =
@"function SCD_2_MATLAB
% function which demonstrates generation of Matlab script
% Author: Nikolai Galkin (nikolai.galkin@ltu.se)

% Name of the model
fname = 'SCD_2_MATLAB';

% Check if the file already exists and delete it if it does
if exist(fname,'file') == 4
    % If it does then check whether it's open
    if bdIsLoaded(fname)
        % If it is then close it (without saving!)
        close_system(fname,0)
    end
    % delete the file
    delete([fname,'.slx']);
end

% Create the system
new_system(fname);" + "\n";

            return script;
        }

        private string InitializeSolverInScript(string _script)
        {
            _script +=
@"% Set a couple of model parameters to eliminate warning messages
set_param(gcs,...
    'Solver','FixedStepDiscrete',...
    'FixedStep','0.1');
% Save the model
save_system(fname);";

            return _script;
        }

        private void GenerateMatlabScript(List<Object_61850> objects_61850)
        {
            string generated_file_path = Directory.GetCurrentDirectory() + @"\SCD_2_MATLAB.m";
            string script = "";
            script = InitializeMatlabScript();
            script = AddObjectsToScript(script, objects_61850);
            script = AddConnectionsToScript(script, objects_61850);
            script = InitializeSolverInScript(script);

            richTextBox1.Text = script;
            /*    if (File.Exists(generated_file_path))
                    File.Delete(generated_file_path);

                using (FileStream fs = File.Create(generated_file_path))
                {
                    byte[] info = new UTF8Encoding(true).GetBytes(script);
                    fs.Write(info, 0, info.Length);
                }*/
        }

        private string AddObjectsToScript(string _script, List<Object_61850> objects_61850)
        {
            int PositionY_top_left_corner = 100;
            int PositionX_top_left_corner = 240;
            int PositionY_bottom_right_corner = 130;
            int PositionX_bottom_right_corner = 270;
            int counter = 0;
            bool is_CON = false;
            foreach (Object_61850 _61850_object in _61850_objects)
            {
                XmlNode NodeGen = xmldoc.SelectSingleNode("configuration");
                foreach (XmlNode childNode in NodeGen.ChildNodes)
                {
                    if (_61850_object.Type == childNode.Attributes.GetNamedItem("name").Value || (is_CON && childNode.Attributes.GetNamedItem("name").Value.Equals("INV")))
                    {
                        _script += "add_block('" + childNode.Attributes.GetNamedItem("path").Value + "', [gcs,'/" + _61850_object.Name + "'],...\n";
                        foreach (XmlNode childNode_1 in childNode.ChildNodes)
                        {
                            _script += childNode_1.InnerText + ",...\n";
                        }

                        _script += "'Position',[" + PositionX_top_left_corner + " " + PositionY_top_left_corner + " " + PositionX_bottom_right_corner + " " + PositionY_bottom_right_corner + "]);\n";
                        counter++;
                        PositionX_top_left_corner += 80;
                        PositionX_bottom_right_corner += 80;
                        if (counter == 3)
                        {
                            PositionX_top_left_corner = 240;
                            PositionX_bottom_right_corner = 270;
                            PositionY_top_left_corner += 80;
                            PositionY_bottom_right_corner += 80;
                            counter = 0;
                        }

                        if (_61850_object.Type.Equals("CON") && is_CON != true)
                            is_CON = true;
                        else
                            is_CON = false;
                        if (!is_CON)
                            break;
                    }
                }
            }
            return _script;
        }

        private string AddConnectionsToScript(string _script, List<Object_61850> objects_61850)
        {
            List<Object_61850> connection_list = new List<Object_61850>();
            string component_side = string.Empty;
            string CON_block_name = string.Empty;
            Object_matlab start_obj = null;
            Object_matlab end_obj = null;
            string current_connection = string.Empty;
            foreach (Object_61850 _61850_object in _61850_objects)
            {
                while (_61850_object.Connection != null)
                {
                    connection_list.Add(_61850_object);
                    foreach (Object_61850 _61850_object_compare in _61850_objects)
                    {
                        if (_61850_object.Name != _61850_object_compare.Name)
                        {
                            if (_61850_object_compare.ConnectionFind(_61850_object.Connection))
                            {
                                connection_list.Add(_61850_object_compare);
                                _61850_object_compare.ConnectionRemove(_61850_object.Connection);
                            }
                        }
                    }
                    current_connection = _61850_object.Connection;
                    _61850_object.ConnectionRemove(_61850_object.Connection);

                    if (connection_list.Count > 1)
                    {
                        Object_61850 basic_node = connection_list.First();
                        foreach (Object_61850 _61850_object_name in connection_list)
                        {
                            if (basic_node.Name != _61850_object_name.Name)
                            {
                                start_obj = MATLAB_objects.Find(x => x.Name.Contains(basic_node.Name));
                                end_obj = MATLAB_objects.Find(x => x.Name.Contains(_61850_object_name.Name));

                                if (current_connection.Equals(basic_node.FirstContName) && current_connection.Equals(_61850_object_name.FirstContName)) //Left-Left connection mode
                                {
                                    if (!start_obj.Port1.Equals("null") && !end_obj.Port1.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port1 + "', '" + end_obj.Name + end_obj.Port1 + "');" + "\n";
                                    if (!start_obj.Port2.Equals("null") && !end_obj.Port2.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port2 + "', '" + end_obj.Name + end_obj.Port2 + "');" + "\n";
                                    if (!start_obj.Port3.Equals("null") && !end_obj.Port3.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port3 + "', '" + end_obj.Name + end_obj.Port3 + "');" + "\n";
                                }
                                else if (current_connection.Equals(basic_node.FirstContName) && current_connection.Equals(_61850_object_name.SecondContName)) //Left-Right connection mode
                                {
                                    if (!start_obj.Port1.Equals("null") && !end_obj.Port4.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port1 + "', '" + end_obj.Name + end_obj.Port4 + "');" + "\n";
                                    if (!start_obj.Port2.Equals("null") && !end_obj.Port5.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port2 + "', '" + end_obj.Name + end_obj.Port5 + "');" + "\n";
                                    if (!start_obj.Port3.Equals("null") && !end_obj.Port6.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port3 + "', '" + end_obj.Name + end_obj.Port6 + "');" + "\n";
                                }
                                else if (current_connection.Equals(basic_node.SecondContName) && current_connection.Equals(_61850_object_name.FirstContName)) //Right-Left connection mode
                                {
                                    if (!start_obj.Port4.Equals("null") && !end_obj.Port1.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port4 + "', '" + end_obj.Name + end_obj.Port1 + "');" + "\n";
                                    if (!start_obj.Port5.Equals("null") && !end_obj.Port2.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port5 + "', '" + end_obj.Name + end_obj.Port2 + "');" + "\n";
                                    if (!start_obj.Port6.Equals("null") && !end_obj.Port3.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port6 + "', '" + end_obj.Name + end_obj.Port3 + "');" + "\n";
                                }
                                else if (current_connection.Equals(basic_node.SecondContName) && current_connection.Equals(_61850_object_name.SecondContName)) //Right-Right connection mode
                                {
                                    if (!start_obj.Port4.Equals("null") && !end_obj.Port4.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port4 + "', '" + end_obj.Name + end_obj.Port4 + "');" + "\n";
                                    if (!start_obj.Port5.Equals("null") && !end_obj.Port5.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port5 + "', '" + end_obj.Name + end_obj.Port5 + "');" + "\n";
                                    if (!start_obj.Port6.Equals("null") && !end_obj.Port6.Equals("null"))
                                        _script += "add_line(gcs, '" + start_obj.Name + start_obj.Port6 + "', '" + end_obj.Name + end_obj.Port6 + "');" + "\n";
                                }
                            }
                        }
                    }
                    connection_list.Clear();
                }
            }
            return _script;
        }

        private void save_matlab_script_btn_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.FileName = "SCD_2_MATLAB";

            saveFileDialog1.DefaultExt = ".m";
            saveFileDialog1.Filter = "Model files (*.m)|*.m";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filename = saveFileDialog1.FileName;

                File.WriteAllText(filename, richTextBox1.Text);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            CPrichText.Text =
@"# OCPP libraries import
from ocpp.routing import on, after
from ocpp.v201 import call
from ocpp.v201 import call_result
from ocpp.v201 import ChargePoint as cp
##############################
# MATLAB.ENGINE library import
import matlab.engine
##############################
#'CBR' type of IEC61850 definition
class CBR :
  name = ''
  current_state = 'open'
  is_changed = False
  connector_id = 0
  connector_status = 'Available'
##############################
class ChargePoint(cp):
    async def send_status_notification(self):
        #initialization of IEC61850 comp. with the 'CBR' type
        global CB10
        global CB11
        global CB12
        ##############################
        #auto-generated checking of 'CBR' components' states 
        if CB10.is_changed == True:
            local_component = CB10
        if CB11.is_changed == True:
            local_component = CB11
        if CB12.is_changed == True:
            local_component = CB12
        ##############################
        #main function's body
        if CB10.is_changed == True || 
           CB11.is_changed == True ||
           CB12.is_changed == True:
        request = call.StatusNotificationPayload(
            timestamp = datetime.utcnow().isoformat(),
            connector_status = local_component.connector_status,
            evse_id = 1,
            connector_id = local_component.connector_id
        )
        response = await self.call(request)
        eng.set_param('untitled/'+local_component.name, 'InitialState',
        local_component.current_state, nargout=0)
        ##############################


















































";

            CMSrichText.Text =
                @"# OCPP libraries import
from ocpp.routing import on, after
from ocpp.v201 import ChargePoint as cp
from ocpp.v201 import call_result, call
##############################
# 'CBR' type of IEC61850 definition
class CBR:
  name = ''
  current_state = 'open'
  is_changed = False
  connector_id = 0
  connector_status = 'Available'
##############################
class ChargePoint(cp):
    @on('StatusNotification')
    async def on_status_notification(self, timestamp, 
    connector_status, evse_id, connector_id, **kwargs):
        #initialization of IEC61850 comp. with the 'CBR' type
        global CB10
        global CB11
        global CB12
        ##############################
        #auto-generated checking of 'CBR' components' states 
        if CB10.connector_id == connector_id:
            CB10.connector_id = connector_id
            CB10.connector_status = connector_status
            local_component = CB10
        if CB11.connector_id == connector_id:
            CB11.connector_id = connector_id
            CB11.connector_status = connector_status
            local_component = CB11
        if CB12.connector_id == connector_id:
            CB12.connector_id = connector_id
            CB12.connector_status = connector_status
            local_component = CB12
        ##############################
        print ('state of component '+local_component.name+
        ' is ' + local_component.current_state)
        return call_result.StatusNotificationPayload()

























































";
        }
}
}
