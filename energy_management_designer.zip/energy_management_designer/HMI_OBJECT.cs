﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace energy_management_designer
{
    public class HMI_OBJECT
    {
        private string type;
        private string text;
        private string name;
        private string related_signal;
        private string posX;
        private string posY;
        private string width;
        private string height;

        public HMI_OBJECT(string type, string name, string text, string related_signal, string posX, string posY, string width, string height)
        {
            this.type = type;
            this.name = name;
            this.text = text;
            this.related_signal = related_signal;
            this.posX = posX;
            this.posY = posY;
            this.width = width;
            this.height = height;
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        public string Text
        {
            get { return text; }
            set { text = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Related_signals
        {
            get { return related_signal; }
            set { related_signal = value; }
        }
        public string PosX
        {
            get { return posX; }
            set { PosX = value; }
        }
        public string PosY
        {
            get { return posY; }
            set { PosY = value; }
        }
        public string Width
        {
            get { return width; }
            set { width = value; }
        }
        public string Height
        {
            get { return height; }
            set { height = value; }
        }
    }
}
