﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace energy_management_designer
{
    public partial class Form2 : Form
    {
        string obj_name = "";
        string _object_parameter = "";
        int _mode = 0;
        public Form2(string name, string object_parameter, int mode)
        {
            InitializeComponent();
            _mode = mode;
            Form1 frm = new Form1();

            if (mode == 0)
            {
                label1.Visible = false;
                textBox1.Visible = false;
                label2.Visible = false;
                numericUpDown1.Visible = false;
                if (name.IndexOf("button_") != -1)
                {
                    frm.loadDataGrid(dataGridView1, "SELECT CS1_signals_cfg.name FROM CS1_signals_cfg WHERE NOT EXISTS(SELECT CS1_HMI_cfg.related_signal FROM CS1_HMI_cfg WHERE CS1_signals_cfg.name = CS1_HMI_cfg.related_signal) AND CS1_signals_cfg.name LIKE 'switch_%'");
                    dataGridView1.Columns[0].Width = dataGridView1.Width;
                }
                else if (name.IndexOf("chart_") != -1)
                {
                    frm.loadDataGrid(dataGridView1, "SELECT CS1_signals_cfg.name FROM CS1_signals_cfg WHERE NOT EXISTS(SELECT CS1_HMI_cfg.related_signal FROM CS1_HMI_cfg WHERE CS1_signals_cfg.name = CS1_HMI_cfg.related_signal) AND (CS1_signals_cfg.name LIKE 'voltage_%' OR CS1_signals_cfg.name LIKE 'current_%')");
                    dataGridView1.Columns[0].Width = dataGridView1.Width;
                }
            }
            else if (mode == 1)
            {
                dataGridView1.Visible = false;
                label2.Visible = false;
                numericUpDown1.Visible = false;
            }
            else if (mode == 2)
            {
                label1.Visible = false;
                textBox1.Visible = false;
                dataGridView1.Visible = false;
            }    

            obj_name = name;
            _object_parameter = object_parameter;
            if (object_parameter == "text")
            {
                this.Text = "change text";
                label1.Text = "new text";
            }
            if (object_parameter == "related_signal")
            {
                this.Text = "change signal";
                label1.Text = "new signal";
            }

        }

        public string button_name { get; set; }
        public string button_text { get; set; }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (_object_parameter == "text")
                {
                    Form1 frm = new Form1();
                    frm.WriteValuetoDatabase("update CS1_HMI_cfg set obj_text = '" + textBox1.Text + "' where name = '" + obj_name + "'");
                    button_name = obj_name;
                    button_text = textBox1.Text;
                    Close();
                }
                if (_object_parameter == "related_signal")
                {
                    Form1 frm = new Form1();
                    frm.WriteValuetoDatabase("update CS1_HMI_cfg set related_signal = '" + textBox1.Text + "' where name = '" + obj_name + "'");
                    button_name = obj_name;
                    button_text = textBox1.Text;
                    Close();
                }
            }
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Form1 frm = new Form1();
            frm.WriteValuetoDatabase("update CS1_HMI_cfg set related_signal = '" + dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString() + "' where name = '" + obj_name + "'");
            Close();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_mode == 2)
            {
                Form1 frm = new Form1();
                frm.WriteValuetoDatabase("update CS1_HMI_cfg set integrety_period = '" + numericUpDown1.Value.ToString() + "' where name = '" + obj_name + "'");
            }
        }
    }
}
