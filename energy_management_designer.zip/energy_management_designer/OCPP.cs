﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace energy_management_designer
{
    public class OCPP : WebSocketBehavior
    {
        string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Environment.CurrentDirectory + "\\database\\config.mdb;";
        int startIndx = 0;
        int length = 0;
        int seqence_number = 0;
        string payload = "";
        Form1 form1 = Application.OpenForms.OfType<Form1>().FirstOrDefault();

        protected override void OnMessage(MessageEventArgs e)
        {
            string str = e.Data.ToString();
            //MessageBox.Show(str);
            if (str.IndexOf("BootNotification") != -1)
            {
                str = str.Substring(4, str.IndexOf("\",") - 4);
                Send("[3,\"" + str + "\",{\"currentTime\":\"2021-12-16T7:07:40.013\",\"interval\": 10, \"status\": \"Accepted\"}]");
            }
            else if (str.IndexOf("Authorize") != -1)
            {
                startIndx = str.IndexOf("type\":\"") + "type\":\"".Length;
                length = str.IndexOf("\"}}]") - startIndx;
                payload = str.Substring(startIndx, length);
                switch (payload)
                {
                    case "KeyCode":
                        startIndx = str.IndexOf("idToken\":\"") + "idToken\":\"".Length;
                        length = 19;
                        payload = str.Substring(startIndx, length);
                        payload = form1.ReadOneValue(connectionString, "SELECT * FROM evID_database where ID = \"" + payload + "\"", "ID");
                        if (payload.Length != 0)
                        {
                            str = str.Substring(4, str.IndexOf("\",") - 4);
                            Send("[3,\"" + str + "\",{\"idTokenInfo\":{\"status\":\"Accepted\"}}]");
                        }
                        else
                            MessageBox.Show("A newly received EV ID does not exist in CMS local database", "EV ID does not exist. Add new?");
                        break;
                    default:
                        MessageBox.Show("OCPP", "OCPP message has incorrect structure");
                        break;
                }
            }
            else if (str.IndexOf("TransactionEvent") != -1)
            {
                startIndx = str.IndexOf("\"seqNo\":") + "\"seqNo\":".Length;
                length = 1;
                payload = str.Substring(startIndx, length);
                int _seqNo = int.Parse(payload);

                if (_seqNo == seqence_number)
                {
                    seqence_number++;
                    str = str.Substring(4, str.IndexOf("\",") - 4);
                    Send("[3,\"" + str + "\",{\"idTokenInfo\":{\"status\":\"Accepted\"}}]");
                }
                else
                {
                    MessageBox.Show("You have this message because seqNo of newly recived message\n is not the same as the internal counter of your CMS", "OCPP TransactionEventRequst has been missed");
                }
            }
            //------------------ @on method ----------------------------
            else if (str.IndexOf("setVariableResult") != -1)
            {
                MessageBox.Show(str);
                //do something
            }
        }
    }
}
